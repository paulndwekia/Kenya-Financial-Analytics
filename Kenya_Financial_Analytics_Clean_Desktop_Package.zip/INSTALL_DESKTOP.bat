@echo off
setlocal
cd /d "%~dp0"

echo ==========================================
echo Kenya Financial Analytics - Desktop Setup
echo ==========================================
echo.

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: .venv was not found.
    echo Please open the working project folder first.
    pause
    exit /b 1
)

echo Installing desktop requirements...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install streamlit pandas numpy scipy plotly pywebview pyinstaller

echo.
echo Setup complete.
echo.
echo You can test the desktop application with:
echo     .venv\Scripts\python.exe desktop_launcher_clean.py
echo.
pause
