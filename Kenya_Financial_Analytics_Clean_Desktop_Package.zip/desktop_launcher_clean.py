import os
import sys
import time
import socket
import subprocess
import threading
import webbrowser
from pathlib import Path

try:
    import webview
except ImportError:
    print("PyWebView is not installed. Run INSTALL_DESKTOP.bat first.")
    raise

PROJECT_DIR = Path(__file__).resolve().parent
APP_FILE = PROJECT_DIR / "app.py"
VENV_PYTHON = PROJECT_DIR / ".venv" / "Scripts" / "python.exe"

def find_free_port(start=8503, end=8599):
    for port in range(start, end + 1):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.15)
            if s.connect_ex(("127.0.0.1", port)) != 0:
                return port
    raise RuntimeError("No free local port was found.")

def wait_for_server(port, timeout=45):
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.4)
    return False

def main():
    if not APP_FILE.exists():
        raise FileNotFoundError(f"Working app.py was not found: {APP_FILE}")

    python = str(VENV_PYTHON) if VENV_PYTHON.exists() else sys.executable
    port = find_free_port()

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"

    cmd = [
        python, "-m", "streamlit", "run", str(APP_FILE),
        "--server.address", "127.0.0.1",
        "--server.port", str(port),
        "--server.headless", "true",
        "--browser.gatherUsageStats", "false",
    ]

    process = subprocess.Popen(
        cmd,
        cwd=str(PROJECT_DIR),
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )

    if not wait_for_server(port):
        process.terminate()
        raise RuntimeError("The financial dashboard did not start within 45 seconds.")

    url = f"http://127.0.0.1:{port}"

    window = webview.create_window(
        "Kenya Financial Analytics",
        url,
        width=1450,
        height=900,
        min_size=(1100, 700),
        resizable=True,
        text_select=True,
    )

    try:
        webview.start()
    finally:
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()

if __name__ == "__main__":
    main()
