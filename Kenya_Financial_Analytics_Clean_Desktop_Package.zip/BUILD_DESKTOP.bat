@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: .venv was not found.
    pause
    exit /b 1
)

echo Installing build tools...
".venv\Scripts\python.exe" -m pip install pywebview pyinstaller

echo.
echo Building the desktop launcher...
echo The EXE will launch the existing working app.py.
echo No dashboard.py is used.
echo.

".venv\Scripts\python.exe" -m PyInstaller ^
 --noconfirm ^
 --clean ^
 --onefile ^
 --windowed ^
 --name "Kenya Financial Analytics" ^
 desktop_launcher_clean.py

echo.
echo ==========================================
echo BUILD COMPLETE
echo ==========================================
echo.
echo EXE:
echo dist\Kenya Financial Analytics.exe
echo.
echo IMPORTANT:
echo Keep the EXE in the main project folder so it can
echo find app.py and .venv.
echo.
pause
