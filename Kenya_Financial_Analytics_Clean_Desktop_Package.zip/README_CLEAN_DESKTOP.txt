KENYA FINANCIAL ANALYTICS - CLEAN DESKTOP BUILD
================================================

Architecture
------------
The desktop application launches the CURRENT working app.py.
It does NOT launch dashboard.py.

Files
-----
desktop_launcher_clean.py
    Native desktop window using PyWebView. Automatically
    selects a free local port and starts Streamlit.

INSTALL_DESKTOP.bat
    Installs Streamlit, PyWebView, PyInstaller and the
    required analytics packages into the existing .venv.

RUN_DESKTOP.bat
    Runs the desktop version directly.

BUILD_DESKTOP.bat
    Builds "Kenya Financial Analytics.exe".

IMPORTANT
---------
Keep the generated EXE in the main project folder beside:
    app.py
    .venv\
    all existing engine modules
    kenya_financial_analytics.db

This build intentionally ignores dashboard.py.

Database
--------
The desktop launcher does not create or replace databases.
It launches the working app.py so the application's existing
database and modules remain unchanged.

Safety
------
No Jarvis components are used.
No files are deleted automatically.
No existing app.py is modified.
